module.exports=[21620,(a,b,c)=>{}];

//# sourceMappingURL=ceffb__next-internal_server_app_restaurant_products_%5BproductId%5D_page_actions_669d6b5c.js.map