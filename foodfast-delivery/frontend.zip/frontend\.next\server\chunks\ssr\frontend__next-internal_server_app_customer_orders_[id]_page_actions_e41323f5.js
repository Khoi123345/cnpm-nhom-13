module.exports=[56308,(a,b,c)=>{}];

//# sourceMappingURL=frontend__next-internal_server_app_customer_orders_%5Bid%5D_page_actions_e41323f5.js.map