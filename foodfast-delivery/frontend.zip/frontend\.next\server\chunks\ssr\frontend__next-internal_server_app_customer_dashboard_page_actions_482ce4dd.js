module.exports=[69595,(a,b,c)=>{}];

//# sourceMappingURL=frontend__next-internal_server_app_customer_dashboard_page_actions_482ce4dd.js.map