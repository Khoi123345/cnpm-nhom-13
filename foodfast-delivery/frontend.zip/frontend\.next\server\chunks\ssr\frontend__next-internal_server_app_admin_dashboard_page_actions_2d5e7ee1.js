module.exports=[18530,(a,b,c)=>{}];

//# sourceMappingURL=frontend__next-internal_server_app_admin_dashboard_page_actions_2d5e7ee1.js.map