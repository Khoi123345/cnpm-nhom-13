module.exports=[82287,(a,b,c)=>{}];

//# sourceMappingURL=frontend__next-internal_server_app_restaurant_dashboard_page_actions_3acbce5a.js.map