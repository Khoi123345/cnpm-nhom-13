module.exports=[95803,(a,b,c)=>{}];

//# sourceMappingURL=frontend__next-internal_server_app_restaurant_settings_page_actions_a48e5887.js.map