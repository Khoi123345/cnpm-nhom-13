globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/f75eddf4d44b73f4.js",
    "static/chunks/d750eda21f6870b8.js",
    "static/chunks/5b38991ac84883e4.js",
    "static/chunks/30eac3aaa2614fcc.js",
    "static/chunks/0e70bba5475a4f47.js",
    "static/chunks/turbopack-65a5eb77911edbbe.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];