module.exports=[57848,(a,b,c)=>{}];

//# sourceMappingURL=frontend__next-internal_server_app_customer_orders_page_actions_3f2a2dcc.js.map