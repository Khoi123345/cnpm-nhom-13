module.exports=[48376,a=>{"use strict";function b(){return null}a.s(["default",()=>b])}];

//# sourceMappingURL=frontend_app_register_loading_tsx_fa512ffb._.js.map