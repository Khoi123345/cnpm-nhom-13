module.exports=[60496,(a,b,c)=>{}];

//# sourceMappingURL=frontend__next-internal_server_app_customer_payment-return_page_actions_593d27ce.js.map