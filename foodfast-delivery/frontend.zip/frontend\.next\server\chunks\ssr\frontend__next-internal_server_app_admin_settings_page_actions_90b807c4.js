module.exports=[14588,(a,b,c)=>{}];

//# sourceMappingURL=frontend__next-internal_server_app_admin_settings_page_actions_90b807c4.js.map